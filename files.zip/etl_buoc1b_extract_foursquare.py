# ============================================================
# BƯỚC 1b: EXTRACT — Lấy data từ Foursquare Places API
# ============================================================
# Foursquare là mạng xã hội check-in địa điểm.
# API của họ miễn phí 1000 request/ngày — đủ cho đồ án.
#
# ĐĂNG KÝ API KEY (miễn phí, không cần thẻ tín dụng):
#   1. Vào https://foursquare.com/developers/home
#   2. Bấm "Create a Free Account"
#   3. Tạo project mới → copy API Key
#   4. Dán vào biến FSQ_API_KEY bên dưới
#
# Cài thư viện cần thiết:
#   pip install requests python-dotenv
# ============================================================

import requests
import json
import time
import os
from dotenv import load_dotenv  # Đọc API key từ file .env cho an toàn

load_dotenv()  # Đọc file .env trong thư mục hiện tại

# ------------------------------------------------------------
# PHẦN 1: Cấu hình
# ------------------------------------------------------------

# Lấy API key từ biến môi trường (an toàn hơn viết thẳng vào code)
# Trong file .env của bạn, thêm dòng: FSQ_API_KEY=your_key_here
FSQ_API_KEY = os.getenv("FSQ_API_KEY", "")

# Nếu chưa có .env, có thể tạm thời điền thẳng vào đây để test:
# FSQ_API_KEY = "fsq3xxxxxxxxxxxxx"  # Xóa sau khi test xong!

if not FSQ_API_KEY:
    print("❌ Chưa có FSQ_API_KEY!")
    print("   1. Đăng ký tại https://foursquare.com/developers/home")
    print("   2. Thêm vào file .env: FSQ_API_KEY=your_key_here")
    exit(1)

# URL gốc của Foursquare API v3
FSQ_BASE_URL = "https://api.foursquare.com/v3/places/search"

# Tọa độ trung tâm Dương Đông
LAT = 10.2167
LON = 103.9667
RADIUS = 12000  # 12km

# Category codes của Foursquare
# Xem đầy đủ tại: https://docs.foursquare.com/data-products/docs/categories
LOAI_DIA_DIEM = [
    # (category_id,  nhãn,         mô tả để hiểu)
    ("13065",       "nha_hang",   "Nhà hàng"),
    ("13032",       "nha_hang",   "Quán ăn bình dân"),
    ("13003",       "nha_hang",   "Quán bar/bia"),
    ("19014",       "khach_san",  "Khách sạn"),
    ("19020",       "khach_san",  "Hostel/nhà trọ"),
    ("16000",       "tham_quan",  "Địa điểm tham quan"),
    ("16020",       "tham_quan",  "Khu vui chơi"),
    ("16032",       "tham_quan",  "Bãi biển"),
    ("10000",       "tham_quan",  "Khu du lịch / Resort"),
]

# ------------------------------------------------------------
# PHẦN 2: Hàm gọi Foursquare API
# ------------------------------------------------------------

def lay_data_foursquare(category_id, category_label, category_desc):
    """
    Gọi Foursquare API để tìm địa điểm theo category.
    
    Foursquare trả về JSON với structure:
    {
      "results": [
        {
          "name": "...",
          "location": { "address": "...", ... },
          "rating": 8.5,
          ...
        }
      ]
    }
    """
    print(f"  ⏳ Đang tìm [{category_desc}]...")
    
    # Headers: cách "xưng danh" với Foursquare API
    # Phải có Authorization header chứa API key
    headers = {
        "Authorization": FSQ_API_KEY,
        "Accept": "application/json"
    }
    
    # Parameters: các bộ lọc tìm kiếm
    params = {
        "ll":           f"{LAT},{LON}",      # tọa độ trung tâm
        "radius":       RADIUS,               # bán kính tìm kiếm (mét)
        "categories":   category_id,          # loại địa điểm
        "limit":        50,                   # tối đa 50 kết quả/request
        "fields":       ",".join([           # chỉ lấy những field cần thiết
            "name",
            "location",
            "rating",
            "hours",
            "price",
            "description",
            "tel",
            "website",
            "tips",
            "stats"
        ])
    }
    
    try:
        response = requests.get(FSQ_BASE_URL, headers=headers, params=params, timeout=15)
        response.raise_for_status()
        
        raw_data = response.json()
        places = raw_data.get("results", [])
        
        ket_qua = []
        for place in places:
            location = place.get("location", {})
            
            # Lấy giờ mở cửa (Foursquare trả về dạng list)
            hours_data = place.get("hours", {})
            gio_mo_cua = ""
            if hours_data:
                # display là chuỗi text đẹp sẵn, ví dụ "Mon-Sun 8AM-10PM"
                gio_mo_cua = hours_data.get("display", "")
            
            # Lấy tip (review ngắn) đầu tiên nếu có
            tips = place.get("tips", [])
            review = tips[0].get("text", "") if tips else ""
            
            # Chuyển price (0-4) sang text dễ hiểu
            price_map = {1: "Rẻ", 2: "Vừa", 3: "Đắt", 4: "Rất đắt"}
            price_level = place.get("price", 0)
            gia_ca = price_map.get(price_level, "Không rõ")
            
            ket_qua.append({
                "ten":          place.get("name", ""),
                "category":     category_label,
                "dia_chi":      location.get("formatted_address", "Phú Quốc"),
                "so_dien_thoai":place.get("tel", ""),
                "website":      place.get("website", ""),
                "mo_ta":        place.get("description", ""),
                "gio_mo_cua":   gio_mo_cua,
                "danh_gia":     place.get("rating", ""),   # thang điểm 10
                "gia_ca":       gia_ca,
                "review":       review,
                "nguon":        "foursquare"
            })
        
        print(f"  ✅ Tìm được {len(ket_qua)} địa điểm")
        return ket_qua
    
    except requests.exceptions.HTTPError as e:
        # Lỗi 401 = API key sai, 429 = vượt quota
        if response.status_code == 401:
            print(f"  ❌ API key sai hoặc hết hạn!")
        elif response.status_code == 429:
            print(f"  ⚠️  Vượt quota 1000 req/ngày! Thử lại ngày mai.")
        else:
            print(f"  ❌ HTTP Error: {e}")
        return []
    except Exception as e:
        print(f"  ❌ Lỗi không xác định: {e}")
        return []

# ------------------------------------------------------------
# PHẦN 3: Chạy Extract
# ------------------------------------------------------------

def chay_extract():
    print("=" * 50)
    print("🚀 BẮT ĐẦU EXTRACT TỪ FOURSQUARE")
    print("=" * 50)
    
    tat_ca = []
    ten_da_co = set()
    
    for cat_id, label, desc in LOAI_DIA_DIEM:
        ket_qua = lay_data_foursquare(cat_id, label, desc)
        
        for item in ket_qua:
            if item["ten"] and item["ten"] not in ten_da_co:
                ten_da_co.add(item["ten"])
                tat_ca.append(item)
        
        # Nghỉ 0.5 giây giữa các request
        time.sleep(0.5)
    
    os.makedirs("data", exist_ok=True)
    
    output_path = "data/raw_foursquare.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(tat_ca, f, ensure_ascii=False, indent=2)
    
    print()
    print("=" * 50)
    print(f"✅ HOÀN THÀNH EXTRACT FOURSQUARE!")
    print(f"📦 Tổng số địa điểm: {len(tat_ca)}")
    print(f"💾 Đã lưu vào: {output_path}")
    print("=" * 50)
    print()
    print("👉 BƯỚC TIẾP THEO: Chạy etl_buoc2_transform.py")

if __name__ == "__main__":
    chay_extract()
