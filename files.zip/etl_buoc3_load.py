# ============================================================
# BƯỚC 3: LOAD — Chuyển data thành file .txt cho RAG
# ============================================================
# Sau bước Transform, chúng ta có data/cleaned.json sạch sẽ.
#
# Bước Load sẽ:
#   1. Đọc cleaned.json
#   2. Chia theo category (nhà hàng, khách sạn, tham quan)
#   3. Chuyển mỗi địa điểm thành đoạn text tự nhiên
#   4. Ghi vào DuLich.txt và DatPhong.txt
#      (đúng tên mà main.py của bạn đang đọc)
#   5. Xóa chroma_db cũ để rebuild
#
# Đây là bước cuối của ETL pipeline!
# ============================================================

import json
import os
import shutil  # Dùng để xóa thư mục (shutil.rmtree)

# ------------------------------------------------------------
# PHẦN 1: Hàm chuyển 1 địa điểm thành đoạn text
# ------------------------------------------------------------

def tao_doan_text(item):
    """
    Chuyển 1 dict địa điểm → 1 đoạn text tự nhiên.
    
    Tại sao cần format text tự nhiên?
    - RAG hoạt động bằng cách tìm đoạn text gần nghĩa với câu hỏi
    - Text tự nhiên giúp embedding model hiểu ngữ cảnh tốt hơn
    - Tránh format quá cứng nhắc như CSV
    
    Ví dụ đầu ra:
    ---
    TÊN: Bún Quậy Kiến Xây
    LOẠI: Nhà hàng / Ăn uống
    ĐỊA CHỈ: 122 Trần Hưng Đạo, Dương Đông, Phú Quốc
    GIỜ MỞ CỬA: 6:00 - 12:00
    GIÁ: Rẻ
    MÔ TẢ: Quán bún quậy nổi tiếng nhất thị trấn Dương Đông.
    ĐÁNH GIÁ KHÁCH: Quán rất ngon, đặc sản Phú Quốc không thể bỏ qua.
    ---
    """
    
    # Map category code → tên tiếng Việt đẹp
    category_map = {
        "nha_hang":  "Nhà hàng / Ăn uống",
        "khach_san": "Khách sạn / Lưu trú",
        "tham_quan": "Địa điểm tham quan",
    }
    loai = category_map.get(item.get("category", ""), "Địa điểm")
    
    # Bắt đầu xây dựng đoạn text
    # Dùng list rồi join để dễ quản lý hơn cộng chuỗi
    dong = []
    
    dong.append(f"TÊN: {item['ten']}")
    dong.append(f"LOẠI: {loai}")
    dong.append(f"ĐỊA CHỈ: {item['dia_chi']}")
    
    if item.get("so_dien_thoai"):
        dong.append(f"SỐ ĐIỆN THOẠI: {item['so_dien_thoai']}")
    
    if item.get("gio_mo_cua"):
        dong.append(f"GIỜ MỞ CỬA: {item['gio_mo_cua']}")
    
    if item.get("gia_ca") and item["gia_ca"] != "Không rõ":
        dong.append(f"MỨC GIÁ: {item['gia_ca']}")
    
    if item.get("danh_gia"):
        dong.append(f"ĐÁNH GIÁ: {item['danh_gia']}/10")
    
    if item.get("mo_ta"):
        dong.append(f"MÔ TẢ: {item['mo_ta']}")
    
    if item.get("review"):
        dong.append(f"NHẬN XÉT KHÁCH: {item['review']}")
    
    if item.get("website"):
        dong.append(f"WEBSITE: {item['website']}")
    
    # Ghép tất cả dòng bằng newline
    return "\n".join(dong)

# ------------------------------------------------------------
# PHẦN 2: Hàm Load chính
# ------------------------------------------------------------

def chay_load():
    print("=" * 50)
    print("💾 BẮT ĐẦU LOAD")
    print("=" * 50)
    
    # Bước 3.1: Đọc file đã cleaned
    cleaned_path = "data/cleaned.json"
    if not os.path.exists(cleaned_path):
        print("❌ Không tìm thấy data/cleaned.json!")
        print("   Hãy chạy etl_buoc2_transform.py trước.")
        return
    
    with open(cleaned_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    print(f"\n📂 Đọc {len(data)} địa điểm từ cleaned.json")
    
    # Bước 3.2: Phân loại theo category
    # Dùng dict comprehension để tạo 3 nhóm
    nha_hang  = [item for item in data if item["category"] == "nha_hang"]
    khach_san = [item for item in data if item["category"] == "khach_san"]
    tham_quan = [item for item in data if item["category"] == "tham_quan"]
    
    print(f"\n📊 Phân loại:")
    print(f"   🍜 Nhà hàng:  {len(nha_hang)}")
    print(f"   🏨 Khách sạn: {len(khach_san)}")
    print(f"   🏛️  Tham quan: {len(tham_quan)}")
    
    # Bước 3.3: Chuyển thành text
    
    # --- DuLich.txt: tham quan + nhà hàng ---
    # (main.py của bạn đang load file này cho agent "dulich")
    
    du_lich_items = tham_quan + nha_hang
    
    du_lich_blocks = []
    for item in du_lich_items:
        du_lich_blocks.append(tao_doan_text(item))
    
    # Nối các địa điểm bằng dòng phân cách
    # "\n\n---\n\n" giúp split_chunks() trong main.py nhận ra ranh giới đoạn tốt hơn
    du_lich_content = "\n\n---\n\n".join(du_lich_blocks)
    
    # Thêm header giải thích cho LLM
    du_lich_content = """THÔNG TIN DU LỊCH KHU BẮC ĐẢO PHÚ QUỐC
Dữ liệu địa điểm tham quan và ăn uống tại Phú Quốc, Kiên Giang.

""" + du_lich_content
    
    # --- DatPhong.txt: khách sạn ---
    # (main.py của bạn đang load file này cho agent "datphong")
    
    dat_phong_blocks = []
    for item in khach_san:
        dat_phong_blocks.append(tao_doan_text(item))
    
    dat_phong_content = "\n\n---\n\n".join(dat_phong_blocks)
    
    dat_phong_content = """THÔNG TIN CHỖ Ở KHU BẮC ĐẢO PHÚ QUỐC
Dữ liệu khách sạn, homestay, nhà trọ tại Phú Quốc, Kiên Giang.

""" + dat_phong_content
    
    # Bước 3.4: Ghi ra file
    print("\n✍️  Đang ghi file...")
    
    with open("data/DuLich.txt", "w", encoding="utf-8") as f:
        f.write(du_lich_content)
    print(f"  ✅ data/DuLich.txt  ({len(du_lich_items)} địa điểm, {len(du_lich_content)} ký tự)")
    
    with open("data/DatPhong.txt", "w", encoding="utf-8") as f:
        f.write(dat_phong_content)
    print(f"  ✅ data/DatPhong.txt ({len(khach_san)} địa điểm, {len(dat_phong_content)} ký tự)")
    
    # Bước 3.5: Xóa chroma_db cũ để force rebuild
    # QUAN TRỌNG: Nếu không xóa, main.py sẽ dùng vector DB cũ!
    chroma_path = "./chroma_db"
    if os.path.exists(chroma_path):
        shutil.rmtree(chroma_path)
        print(f"\n🗑️  Đã xóa chroma_db cũ → sẽ được rebuild khi chạy main.py")
    else:
        print(f"\n  ℹ️  Chưa có chroma_db, sẽ được tạo mới khi chạy main.py")
    
    print()
    print("=" * 50)
    print("🎉 HOÀN THÀNH ETL PIPELINE!")
    print("=" * 50)
    print()
    print("👉 BƯỚC CUỐI: Chạy main.py để chatbot dùng data mới!")
    print("   uvicorn main:app --reload")

if __name__ == "__main__":
    chay_load()
