# ============================================================
# CHẠY TOÀN BỘ ETL PIPELINE (1 lần duy nhất)
# ============================================================
# File này gọi cả 3 bước theo thứ tự:
#   Bước 1: Extract (OSM + Foursquare)
#   Bước 2: Transform (làm sạch, dedup)
#   Bước 3: Load (ghi ra .txt, xóa chroma_db cũ)
#
# CÁCH CHẠY:
#   python etl_run_all.py
#
# Yêu cầu: đã có FSQ_API_KEY trong file .env (nếu muốn dùng Foursquare)
# ============================================================

import subprocess
import sys
import os

def chay_buoc(ten_buoc, ten_file):
    """Chạy 1 script Python và kiểm tra kết quả"""
    print(f"\n{'='*50}")
    print(f"▶️  {ten_buoc}")
    print(f"{'='*50}")
    
    # subprocess.run chạy 1 lệnh shell từ bên trong Python
    # sys.executable là đường dẫn Python hiện tại (đảm bảo đúng môi trường)
    result = subprocess.run(
        [sys.executable, ten_file],
        capture_output=False  # Hiển thị output ra màn hình luôn
    )
    
    if result.returncode != 0:
        print(f"\n❌ {ten_buoc} gặp lỗi! Dừng lại.")
        sys.exit(1)
    
    print(f"\n✅ {ten_buoc} xong!")

if __name__ == "__main__":
    print("🚀 BẮT ĐẦU TOÀN BỘ ETL PIPELINE")
    print("📍 Phú Quốc — Khu Bắc Đảo")
    
    # Kiểm tra .env có FSQ_API_KEY không
    from dotenv import load_dotenv
    load_dotenv()
    
    co_foursquare = bool(os.getenv("FSQ_API_KEY"))
    if not co_foursquare:
        print("\n⚠️  Không tìm thấy FSQ_API_KEY trong .env")
        print("   Sẽ chỉ dùng OpenStreetMap (vẫn ổn!)")
    
    # Bước 1a: Extract từ OpenStreetMap (luôn chạy)
    chay_buoc("BƯỚC 1a: Extract OpenStreetMap", "etl_buoc1_extract_osm.py")
    
    # Bước 1b: Extract từ Foursquare (chỉ nếu có API key)
    if co_foursquare:
        chay_buoc("BƯỚC 1b: Extract Foursquare", "etl_buoc1b_extract_foursquare.py")
    
    # Bước 2: Transform
    chay_buoc("BƯỚC 2: Transform & Clean", "etl_buoc2_transform.py")
    
    # Bước 3: Load
    chay_buoc("BƯỚC 3: Load → .txt files", "etl_buoc3_load.py")
    
    print("\n" + "="*50)
    print("🎉 ETL PIPELINE HOÀN TẤT!")
    print("="*50)
    print("\nChạy chatbot:")
    print("  uvicorn main:app --reload")
