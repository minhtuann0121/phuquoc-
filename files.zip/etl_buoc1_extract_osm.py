# ============================================================
# BƯỚC 1: EXTRACT — Lấy data từ OpenStreetMap (OSM)
# ============================================================
# OpenStreetMap là bản đồ mở, ai cũng có thể dùng miễn phí.
# Overpass API là cổng để "hỏi" OSM: "cho tôi tất cả nhà hàng ở Phú Quốc"
#
# Cài thư viện cần thiết:
#   pip install requests
# ============================================================

import requests  # Dùng để gửi request lên internet (giống như mở trình duyệt bằng code)
import json      # Dùng để đọc/ghi file JSON
import time      # Dùng để tạm dừng giữa các request (tránh bị block)
import os        # Dùng để tạo thư mục

# ------------------------------------------------------------
# PHẦN 1: Cấu hình — Khai báo những gì cần tìm
# ------------------------------------------------------------

# URL của Overpass API — đây là "địa chỉ" để gửi câu hỏi đến OSM
OVERPASS_URL = "https://overpass-api.de/api/interpreter"

# Tọa độ trung tâm Dương Đông, Bắc Phú Quốc
# Mở Google Maps, chuột phải vào điểm bất kỳ → sẽ thấy tọa độ
LAT = 10.2167
LON = 103.9667
RADIUS = 12000  # 12km tính từ trung tâm (đủ bao phủ khu Bắc đảo)

# Danh sách những loại địa điểm muốn lấy
# Format: (tên_tag_OSM, giá_trị_tag, nhãn_của_mình)
#
# OSM dùng hệ thống "tag" để phân loại địa điểm:
#   amenity=restaurant  →  nhà hàng
#   tourism=hotel       →  khách sạn
#   tourism=attraction  →  điểm tham quan
#   v.v.
LOAI_DIA_DIEM = [
    ("amenity", "restaurant",   "nha_hang"),
    ("amenity", "cafe",         "nha_hang"),
    ("amenity", "food_court",   "nha_hang"),
    ("tourism", "hotel",        "khach_san"),
    ("tourism", "guest_house",  "khach_san"),
    ("tourism", "hostel",       "khach_san"),
    ("tourism", "attraction",   "tham_quan"),
    ("tourism", "museum",       "tham_quan"),
    ("leisure", "park",         "tham_quan"),
    ("amenity", "marketplace",  "tham_quan"),  # Chợ đêm Dương Đông
]

# ------------------------------------------------------------
# PHẦN 2: Hàm xây câu query để "hỏi" OSM
# ------------------------------------------------------------

def tao_cau_query(tag_key, tag_value, lat, lon, radius):
    """
    Hàm này tạo ra "câu hỏi" gửi lên Overpass API.
    
    Overpass dùng ngôn ngữ riêng (QL), nhưng bạn không cần học sâu.
    Hiểu đơn giản: "Tìm tất cả node/way có tag X=Y trong vòng R mét quanh tọa độ (lat, lon)"
    
    node = điểm đơn (1 tọa độ)
    way  = đường/vùng (nhiều tọa độ nối lại, ví dụ: khuôn viên resort)
    out center = với "way", trả về tọa độ trung tâm thay vì toàn bộ đường viền
    """
    query = f"""
    [out:json][timeout:25];
    (
      node["{tag_key}"="{tag_value}"](around:{radius},{lat},{lon});
      way["{tag_key}"="{tag_value}"](around:{radius},{lat},{lon});
    );
    out body;
    >;
    out skel qt;
    """
    return query

# ------------------------------------------------------------
# PHẦN 3: Hàm gửi request và nhận data về
# ------------------------------------------------------------

def lay_data_osm(tag_key, tag_value, category_label):
    """
    Gửi câu query lên OSM, nhận về danh sách địa điểm.
    
    Trả về: list các dict, mỗi dict là 1 địa điểm
    """
    print(f"  ⏳ Đang tìm [{tag_key}={tag_value}]...")
    
    query = tao_cau_query(tag_key, tag_value, LAT, LON, RADIUS)
    
    try:
        # Gửi request lên Overpass API
        # timeout=30: nếu 30 giây không có phản hồi thì bỏ qua
        response = requests.get(
            OVERPASS_URL,
            params={"data": query},
            timeout=30
        )
        
        # Kiểm tra xem request có thành công không (status 200 = OK)
        response.raise_for_status()
        
        # Chuyển response từ dạng text JSON → Python dict
        raw_data = response.json()
        
        # OSM trả về trong key "elements" — đây là danh sách địa điểm
        elements = raw_data.get("elements", [])
        
        # Lọc và chuẩn hóa data
        ket_qua = []
        for element in elements:
            tags = element.get("tags", {})
            
            # Bỏ qua nếu không có tên (không hữu ích cho chatbot)
            ten = tags.get("name") or tags.get("name:vi") or tags.get("name:en")
            if not ten:
                continue
            
            # Lấy tọa độ
            # node có lat/lon trực tiếp, way có trong "center"
            if element["type"] == "node":
                lat_item = element.get("lat")
                lon_item = element.get("lon")
            else:
                center = element.get("center", {})
                lat_item = center.get("lat")
                lon_item = center.get("lon")
            
            ket_qua.append({
                "ten":          ten,
                "category":     category_label,
                "dia_chi":      tags.get("addr:full") or tags.get("addr:street", "Phú Quốc"),
                "so_dien_thoai":tags.get("phone") or tags.get("contact:phone", ""),
                "website":      tags.get("website") or tags.get("contact:website", ""),
                "mo_ta":        tags.get("description") or tags.get("note", ""),
                "gio_mo_cua":   tags.get("opening_hours", ""),
                "lat":          lat_item,
                "lon":          lon_item,
                "nguon":        "openstreetmap"
            })
        
        print(f"  ✅ Tìm được {len(ket_qua)} địa điểm")
        return ket_qua
    
    except requests.exceptions.Timeout:
        print(f"  ⚠️  Timeout! Bỏ qua [{tag_key}={tag_value}]")
        return []
    except Exception as e:
        print(f"  ❌ Lỗi: {e}")
        return []

# ------------------------------------------------------------
# PHẦN 4: Chạy Extract — Lấy tất cả loại địa điểm
# ------------------------------------------------------------

def chay_extract():
    """
    Hàm chính: lần lượt gọi từng loại địa điểm, gom lại thành 1 file JSON.
    """
    print("=" * 50)
    print("🚀 BẮT ĐẦU EXTRACT TỪ OPENSTREETMAP")
    print("=" * 50)
    
    tat_ca_dia_diem = []  # List rỗng, sẽ gom tất cả địa điểm vào đây
    ten_da_co = set()     # Set để kiểm tra trùng lặp (set tìm kiếm nhanh hơn list)
    
    for tag_key, tag_value, label in LOAI_DIA_DIEM:
        # Lấy data cho từng loại
        ket_qua = lay_data_osm(tag_key, tag_value, label)
        
        # Loại bỏ trùng lặp (cùng tên thì bỏ)
        for item in ket_qua:
            if item["ten"] not in ten_da_co:
                ten_da_co.add(item["ten"])
                tat_ca_dia_diem.append(item)
        
        # Nghỉ 1 giây giữa các request — lịch sự với server, tránh bị block
        time.sleep(1)
    
    # Tạo thư mục data nếu chưa có
    os.makedirs("data", exist_ok=True)
    
    # Lưu vào file JSON
    output_path = "data/raw_osm.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(tat_ca_dia_diem, f, ensure_ascii=False, indent=2)
    
    print()
    print("=" * 50)
    print(f"✅ HOÀN THÀNH EXTRACT!")
    print(f"📦 Tổng số địa điểm: {len(tat_ca_dia_diem)}")
    print(f"💾 Đã lưu vào: {output_path}")
    print("=" * 50)
    print()
    print("👉 BƯỚC TIẾP THEO: Chạy etl_buoc2_transform.py")

# Điểm bắt đầu của chương trình
# "if __name__ == '__main__'" có nghĩa là:
# "Chỉ chạy phần này khi file được chạy trực tiếp, không phải khi được import"
if __name__ == "__main__":
    chay_extract()
