# ============================================================
# BƯỚC 2: TRANSFORM — Làm sạch và chuẩn hóa data
# ============================================================
# Sau bước Extract, chúng ta có 2 file JSON "thô":
#   - data/raw_osm.json        (từ OpenStreetMap)
#   - data/raw_foursquare.json (từ Foursquare)
#
# Bước Transform sẽ:
#   1. Đọc cả 2 file
#   2. Gộp lại thành 1 danh sách
#   3. Làm sạch (xóa rác, chuẩn hóa)
#   4. Loại bỏ trùng lặp thông minh hơn
#   5. Lưu ra data/cleaned.json
#
# Chạy sau khi đã chạy ít nhất 1 trong 2 script Extract.
# ============================================================

import json
import os
import re  # Regular expression — dùng để tìm và thay thế text theo pattern

# ------------------------------------------------------------
# PHẦN 1: Đọc các file JSON thô từ bước Extract
# ------------------------------------------------------------

def doc_file_json(duong_dan):
    """
    Đọc file JSON, trả về list. Nếu file không tồn tại thì trả về list rỗng.
    Dùng try/except để code không bị crash nếu file chưa có.
    """
    if not os.path.exists(duong_dan):
        print(f"  ⚠️  File không tồn tại, bỏ qua: {duong_dan}")
        return []
    
    with open(duong_dan, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    print(f"  📂 Đọc {duong_dan}: {len(data)} địa điểm")
    return data

# ------------------------------------------------------------
# PHẦN 2: Các hàm làm sạch data
# ------------------------------------------------------------

def lam_sach_ten(ten):
    """
    Chuẩn hóa tên địa điểm.
    Ví dụ: "  nhà hàng  BIỂN XANH " → "Nhà Hàng Biển Xanh"
    """
    if not ten:
        return ""
    
    # Xóa khoảng trắng thừa đầu/cuối
    ten = ten.strip()
    
    # Xóa ký tự đặc biệt lạ (giữ lại chữ, số, dấu tiếng Việt, khoảng trắng, dấu -)
    ten = re.sub(r'[^\w\s\-àáâãèéêìíòóôõùúýăđơưÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝĂĐƠƯ]', '', ten)
    
    # Capitalize từng từ (title case)
    ten = ten.title()
    
    return ten

def lam_sach_dia_chi(dia_chi):
    """
    Chuẩn hóa địa chỉ.
    Nếu địa chỉ trống hoặc quá ngắn → thay bằng "Phú Quốc, Kiên Giang"
    """
    if not dia_chi or len(dia_chi.strip()) < 5:
        return "Phú Quốc, Kiên Giang"
    
    dia_chi = dia_chi.strip()
    
    # Nếu địa chỉ chưa có "Phú Quốc" thì thêm vào
    if "Phú Quốc" not in dia_chi and "Phu Quoc" not in dia_chi:
        dia_chi = dia_chi + ", Phú Quốc"
    
    return dia_chi

def lam_sach_gio(gio):
    """
    Chuẩn hóa giờ mở cửa.
    """
    if not gio:
        return "Liên hệ trước khi đến"
    return str(gio).strip()

def lam_sach_mo_ta(mo_ta):
    """
    Làm sạch mô tả: xóa HTML tags, xóa dòng trắng thừa.
    """
    if not mo_ta:
        return ""
    
    # Xóa HTML tags như <b>, <br>, <p> nếu có
    mo_ta = re.sub(r'<[^>]+>', '', mo_ta)
    
    # Xóa khoảng trắng thừa
    mo_ta = ' '.join(mo_ta.split())
    
    return mo_ta.strip()

def la_dia_diem_hop_le(item):
    """
    Kiểm tra xem địa điểm có đủ thông tin để đưa vào chatbot không.
    
    Trả về True nếu hợp lệ, False nếu cần loại bỏ.
    """
    # Phải có tên
    if not item.get("ten"):
        return False
    
    # Tên quá ngắn (dưới 3 ký tự) → có thể là lỗi data
    if len(item["ten"]) < 3:
        return False
    
    # Loại bỏ những địa điểm không liên quan
    ten_lower = item["ten"].lower()
    tu_loai_tru = ["atm", "ngân hàng", "bank", "xăng", "gas station", "pharmacy", "nhà thuốc"]
    for tu in tu_loai_tru:
        if tu in ten_lower:
            return False
    
    return True

# ------------------------------------------------------------
# PHẦN 3: Loại bỏ trùng lặp thông minh
# ------------------------------------------------------------

def chuan_hoa_de_so_sanh(ten):
    """
    Chuẩn hóa tên để so sánh trùng lặp.
    "Vinpearl Resort & Spa" và "VINPEARL RESORT SPA" → "vinpearl resort spa"
    
    Bỏ dấu tiếng Việt, lowercase, xóa ký tự đặc biệt.
    """
    # Lowercase
    ten = ten.lower()
    
    # Xóa dấu câu và ký tự đặc biệt, giữ chữ và số
    ten = re.sub(r'[^\w\s]', ' ', ten)
    
    # Xóa khoảng trắng thừa
    ten = ' '.join(ten.split())
    
    return ten

def loai_bo_trung_lap(danh_sach):
    """
    Loại bỏ địa điểm trùng tên.
    Nếu 2 nguồn có cùng địa điểm → giữ cái có nhiều thông tin hơn.
    """
    seen = {}  # key: tên chuẩn hóa, value: item đang giữ
    
    for item in danh_sach:
        key = chuan_hoa_de_so_sanh(item["ten"])
        
        if key not in seen:
            # Chưa có → thêm vào
            seen[key] = item
        else:
            # Đã có → so sánh xem cái nào có nhiều thông tin hơn
            cu = seen[key]
            
            # Đếm số field có giá trị (không rỗng)
            diem_moi = sum(1 for v in item.values() if v)
            diem_cu  = sum(1 for v in cu.values()  if v)
            
            # Giữ cái có nhiều thông tin hơn
            if diem_moi > diem_cu:
                seen[key] = item
    
    return list(seen.values())

# ------------------------------------------------------------
# PHẦN 4: Hàm Transform chính
# ------------------------------------------------------------

def transform_mot_item(item):
    """
    Áp dụng tất cả hàm làm sạch lên 1 địa điểm.
    Trả về dict đã được chuẩn hóa.
    """
    return {
        "ten":          lam_sach_ten(item.get("ten", "")),
        "category":     item.get("category", "tham_quan"),
        "dia_chi":      lam_sach_dia_chi(item.get("dia_chi", "")),
        "so_dien_thoai":item.get("so_dien_thoai", "").strip(),
        "website":      item.get("website", "").strip(),
        "mo_ta":        lam_sach_mo_ta(item.get("mo_ta", "")),
        "gio_mo_cua":   lam_sach_gio(item.get("gio_mo_cua", "")),
        "danh_gia":     str(item.get("danh_gia", "")).strip(),
        "gia_ca":       item.get("gia_ca", ""),
        "review":       lam_sach_mo_ta(item.get("review", "")),
        "nguon":        item.get("nguon", "unknown"),
    }

def chay_transform():
    print("=" * 50)
    print("🔄 BẮT ĐẦU TRANSFORM")
    print("=" * 50)
    
    # Bước 2.1: Đọc tất cả file raw
    print("\n📂 Đọc file raw...")
    raw_osm         = doc_file_json("data/raw_osm.json")
    raw_foursquare  = doc_file_json("data/raw_foursquare.json")
    
    # Gộp tất cả lại
    tat_ca_raw = raw_osm + raw_foursquare
    print(f"\n  📊 Tổng raw: {len(tat_ca_raw)} địa điểm")
    
    # Bước 2.2: Làm sạch từng địa điểm
    print("\n🧹 Đang làm sạch data...")
    da_lam_sach = [transform_mot_item(item) for item in tat_ca_raw]
    
    # Bước 2.3: Lọc bỏ địa điểm không hợp lệ
    hop_le = [item for item in da_lam_sach if la_dia_diem_hop_le(item)]
    print(f"  ✅ Sau khi lọc: {len(hop_le)} địa điểm hợp lệ (bỏ {len(da_lam_sach) - len(hop_le)})")
    
    # Bước 2.4: Loại bỏ trùng lặp
    khong_trung = loai_bo_trung_lap(hop_le)
    print(f"  ✅ Sau khi dedup: {len(khong_trung)} địa điểm (bỏ {len(hop_le) - len(khong_trung)} trùng)")
    
    # Thống kê theo category
    from collections import Counter
    stats = Counter(item["category"] for item in khong_trung)
    print(f"\n  📊 Phân bố:")
    for cat, count in stats.items():
        emoji = {"nha_hang": "🍜", "khach_san": "🏨", "tham_quan": "🏛️"}.get(cat, "📍")
        print(f"     {emoji} {cat}: {count} địa điểm")
    
    # Lưu file cleaned
    os.makedirs("data", exist_ok=True)
    output_path = "data/cleaned.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(khong_trung, f, ensure_ascii=False, indent=2)
    
    print()
    print("=" * 50)
    print(f"✅ HOÀN THÀNH TRANSFORM!")
    print(f"💾 Đã lưu vào: {output_path}")
    print("=" * 50)
    print()
    print("👉 BƯỚC TIẾP THEO: Chạy etl_buoc3_load.py")

if __name__ == "__main__":
    chay_transform()
